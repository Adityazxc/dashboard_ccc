<script>
    function detailImage(
        url,
        runsheet_date,
        no_runsheet,
        awb,
        status_cod,
        link_maps,
        id_courier,
        courier_name,
        no_tlp,
        destination_code,
        zone,
        received_date,
        receiver_name,
        receiver_address,
        paymeny_type,
        amount,
        status_via,
        pod_status,
    ) {

        $('#productImageSellingEdit').attr("src", url); // url sudah benar dari PHP
        $(".idReturRemove").text(url);
        $(".runsheet_date").text(runsheet_date);
        $(".awb").text(awb);
        $(".no_runsheet").text(no_runsheet);
        $(".status_cod").html(status_cod + " " + pod_status);
        $("#mapLink").attr("href", link_maps);     
           
        var text = "Mohon untuk memperbaiki foto validasi POD untuk paket dengan nomor AWB *" + awb + "* atas nama *" + receiver_name + "* di alamat *" + receiver_address + "* segera.";
        $("#no_wa").attr("href", "https://wa.me/" + no_tlp + "?text=" + encodeURIComponent(text));
        $(".id_courier").text(id_courier);
        $(".courier_name").text(courier_name);
        $(".no_tlp").text(no_tlp);
        $(".destination_code").text(destination_code);
        $(".zone").text(zone);
        $(".received_date").text(received_date);
        $(".receiver_name").text(receiver_name);
        $(".receiver_address").text(receiver_address);
        $(".paymeny_type").text(paymeny_type);
        $(".amount").text(amount);
        $(".status_via").text(status_via);

    }
    function detailImage_non_approves(
        url,
        runsheet_date,
        no_runsheet,
        awb,
        status_cod,
        link_maps,
        id_courier,
        courier_name,
        no_tlp,
        destination_code,
        zone,
        received_date,
        receiver_name,
        receiver_address,
        paymeny_type,
        amount,
        pod_status,
    ) {

        $('#productImageSellingEdit').attr("src", url); // url sudah benar dari PHP
        $(".idReturRemove").text(url);
        $(".runsheet_date").text(runsheet_date);
        $(".awb").text(awb);
        $(".no_runsheet").text(no_runsheet);
        $(".status_cod").html(status_cod + " " + pod_status);
        $("#mapLink").attr("href", link_maps);        
        var text = "*" + courier_name + "* Mohon untuk memperbaiki foto validasi * awb *" + awb + "pada runsheet tanggal *" + runsheet_date + "* dengan nomor *"+ no_runsheet +"* segera.";
        $("#no_wa").attr("href", "https://wa.me/" + no_tlp + "?text=" + encodeURIComponent(text));
        $(".id_courier").text(id_courier);
        $(".courier_name").text(courier_name);
        $(".no_tlp").text(no_tlp);
        $(".destination_code").text(destination_code);
        $(".zone").text(zone);
        $(".received_date").text(received_date);
        $(".receiver_name").text(receiver_name);
        $(".receiver_address").text(receiver_address);
        $(".paymeny_type").text(paymeny_type);
        $(".amount").text(amount);

    }
</script>

<div class="modal fade" id="ModalDetailImage" tabindex="-1" role="dialog" aria-labelledby="ModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold" id="ModalLabel">Detail Image</h5>
                <!-- Tombol Close -->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">                    
                </button>
            </div>
            <form action="<?= base_url('retur/delete_retur') ?>" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="container mt-4">
                        <div class="row">
                            <!-- Kolom Gambar -->
                            <div class="col-md-6">
                                <center>

                                    <img id="productImageSellingEdit" src="" class="img-thumbnail image-box"
                                        width="200">
                                </center>
                            </div>

                            <!-- Kolom Detail Informasi -->
                            <div class="col-md-6">
                                <div class="row">
                                    <!-- AWB Baris 1 -->
                                    <div class="col-lg-12 border-bottom">
                                        <p class="sub-header mb-0 mt-2"><strong>AWB</strong></p>
                                        <p class="text-left awb"></p>
                                    </div>

                                    <!-- AWB Baris 2 -->
                                    <div class="col-lg-12 border-bottom">
                                        <p class="sub-header mb-0 mt-2"><strong>No Runsheet</strong></p>
                                        <p class="text-left no_runsheet"></p>
                                    </div>

                                    <!-- AWB Baris 3 -->
                                    <div class="col-lg-12 border-bottom">
                                        <p class="sub-header mb-0 mt-2"><strong>Status Code</strong></p>
                                        <p class="text-left status_cod"></p>
                                    </div>

                                    <div class="col-lg-12 border-bottom">
                                        <p class="sub-header mb-0 mt-2"><strong>Lokasi</strong></p>
                                        <a href="" id="mapLink" target="_blank">
                                            <i class="bi bi-geo-alt">
                                                Buka di google maps
                                            </i>
                                        </a>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <p id="message-warning-delete"></p>

                        <center>

                            <p class="h3">Detail Runsheet</p>
                        </center>
                        <div class="row task-dates mb-0 mt-2">
                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Tanggal Runsheet</strong></p>
                                <p class="text-left no_runsheet"></p>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>ID Kurir</strong></p>
                                <p class="text-left id_courier"></p>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Nama Kurir</strong></p>
                                <p class="text-left courier_name"></p>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Kontak Kurir</strong></p>
                                <div class="col-sm">
                                    <a href="" id="no_wa" target="_blank">
                                        <i class="bi bi-whatsapp">
                                            <text class="text-left no_tlp"></text>
                                        </i>
                                    </a>
                                </div>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Destinasi</strong></p>
                                <p class="text-left destination_code"></p>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Zona</strong></p>
                                <p class="text-left zone"></p>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Alamat Penerima</strong></p>
                                <p class="text-left receiver_address"></p>
                            </div>
                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Status Via</strong></p>
                                <p class="text-left status_via"></p>
                            </div>
                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Tanggal Diterima</strong></p>
                                <p class="text-left received_date"></p>
                            </div>


                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Nama Penerima</strong></p>
                                <p class="text-left receiver_name"></p>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Type Payment</strong></p>
                                <p class="text-left paymeny_type"></p>
                            </div>

                            <div class="col-lg-6 border-bottom">
                                <p class="sub-header mb-0 mt-2"><strong>Amount</strong></p>
                                <p class="text-left amount"></p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <!-- Tombol Close (Footer) -->
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <!-- Tombol Reset -->
                        <!-- <button type="submit" class="btn btn-primary col-md-2">Edit</button> -->
                    </div>
            </form>
        </div>
    </div>
</div>