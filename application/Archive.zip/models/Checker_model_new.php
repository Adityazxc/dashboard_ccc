<?php

class Checker_model extends CI_Model
{

    var $checker_column_order = array(null, "ch.id_courier","courier_name", "awb", "receiver_name"); //set column field database for datatable orderable
    var $checker_column_search = array("ch.id_courier","courier_name", "awb", "receiver_name"); //set column field database for datatable searchable

    private function _getdatatables_checker()
    {
        $this->db->select('*,
            ch.id_courier,
            ch.runsheet_date,
            COUNT(ch.id_courier) as qty_awb,
            SUM(CASE WHEN ch.status_checker = "Sesuai" THEN 1 ELSE 0 END) as qty_sesuai,
            SUM(CASE WHEN ch.status_checker = "Tidak Sesuai" THEN 1 ELSE 0 END) as qty_tidak_sesuai
        ');
        $this->db->from('checker ch');
        $this->db->join('courier c', 'c.id_courier = ch.id_courier', 'left');
        $this->db->group_by(['ch.id_courier', 'DATE(ch.runsheet_date)']); // Tambahkan hrs_date ke GROUP BY        

        // $this->db->join('products p', 's.id_product = p.id_product', 'left');

        // $dateFrom = $this->input->post('dateFrom', TRUE);
        // $dateThru = $this->input->post('dateThru', TRUE);
        // $area = $this->input->post('area', TRUE);
        // $zona = $this->input->post('zona', TRUE);

        // // Pastikan $dateFrom dan $dateThru memiliki nilai sebelum digunakan dalam kondisi
        // if (!empty($dateFrom) && !empty($dateThru)) {
        //     $this->db->where('DATE(ch.create_date) >=', $dateFrom);
        //     $this->db->where('DATE(ch.create_date) <=', $dateThru);
        // }
        // if (!empty($zona) || !empty($area)) {
        //     $this->db->where('ch.zone', $zona);
        //     $this->db->where('ch.destination_code', $area);
        // }


        $i = 0;

        if (@$_POST['search']['value']) {
            foreach ($this->checker_column_search as $item) {
                if ($i === 0) {
                    $this->db->group_start()
                        ->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->checker_column_search) - 1 == $i) {
                    $this->db->group_end();
                }
                $i++;
            }
        }

        if (isset($_POST['order'])) {
            $this->db->order_by($this->checker_column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } elseif (isset($this->order)) {
            $checker_order = $this->order;
            $this->db->order_by(key($checker_order), $checker_order[key($checker_order)]);
        }
    }

    function getdatatables_checker()
    {
        $this->_getdatatables_checker();
        if (@$_POST['length'] != -1)
            $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_checker()
    {
        $this->_getdatatables_checker();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_checker()
    {

        $this->db->select('*');
        $this->db->from('checker');
        return $this->db->count_all_results();
    }

    public function _add_checker($data)
    {
        try {
            $this->db->insert_batch('checker', $data);
            return TRUE;
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
            return FALSE;
        }

        // return $data;
    }
    public function _add_status($data)
    {
        try {
            $this->db->insert_batch('checker', $data);
            return TRUE;
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
            return FALSE;
        }
    }
    public function _change_status($id_courier, $id_checker)
    {
        try {
            $this->db->where_in('id_checker', $id_checker); // Bisa menerima array
            $this->db->update('checker', ['status_checker' => "Tidak Sesuai"]);

            return $this->db->affected_rows() > 0; // Pastikan ada data yang terupdate
        } catch (Exception $e) {
            return false;
        }
    }
    public function _change_status_approve($id_courier, $id_checker)
    {
        try {
            $this->db->where_in('id_checker', $id_checker); // Bisa menerima array
            $this->db->update('checker', ['status_checker' => "Sesuai"]);

            return $this->db->affected_rows() > 0; // Pastikan ada data yang terupdate
        } catch (Exception $e) {
            return false;
        }
    }


    function _get_data_approve($id_courier,$runsheet_date)
    {
        $this->db->select("ch.*, c.*, s.*");
        $this->db->from("checker ch");
        $this->db->join("courier c", 'c.id_courier=ch.id_courier', 'left');
        $this->db->join("status_pod s", 's.pod_code=ch.status_cod', 'left');
        $this->db->where("ch.id_courier", $id_courier);
        $this->db->where("DATE(ch.runsheet_date)", date('Y-m-d', strtotime($runsheet_date)));

        $this->db->where("ch.status_checker", "Sesuai");

        // $this->db->where("runsheet_date",$runsheet_date);

        $query = $this->db->get();
        return $query->result();

    }
    function _get_data_not_approve($id_courier,$runsheet_date)
    {
        $this->db->select("ch.*,c.*,s.*");
        $this->db->from("checker ch");
        $this->db->join("courier c", 'c.id_courier=ch.id_courier', 'left');
        $this->db->join("status_pod s", 's.pod_code=ch.status_cod', 'left');
        $this->db->where("ch.id_courier", $id_courier);
        $this->db->where("DATE(ch.runsheet_date)", date('Y-m-d', strtotime($runsheet_date)));

        $this->db->where("ch.status_checker", "Tidak Sesuai");
        // $this->db->where("runsheet_date",$runsheet_date);

        $query = $this->db->get();
        return $query->result();

    }

    function _get_data_courier($id_courier)
    {
        $this->db->select("*");
        $this->db->from("courier");
        $this->db->where("id_courier", $id_courier);
        $query = $this->db->get();
        return $query->row();
    }

    function _duplicat_awb($awb)
    {
        $this->db->where('awb', $awb);
        $query = $this->db->get('checker'); // Ganti 'your_table_name' dengan nama tabel yang sesuai  
        // Mengembalikan true jika ada data yang ditemukan, false jika tidak ada  
        return $query->num_rows() > 0;
    }
}
?>