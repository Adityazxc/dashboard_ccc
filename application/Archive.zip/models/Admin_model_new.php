∫<?php

class Admin_model extends CI_Model
{
    var $customer_column_order = array(null, 'id_user', 'account_name','employee_position','regional','branch','origin','zone','username','kpi', 'role',  null); //set column field database for datatable orderable
    var $customer_column_search = array('id_user', 'account_name','employee_position','regional','branch','origin','zone','username','kpi', 'role',  ); //set column field database for datatable searchable
    var $customer_order = array('id' => 'DESC');

    private function _getdatatables_customer()
    {
        //
        $this->db->select('*');
        // $this->db->order_by('id_user','DESC');
        // $this->db->where('username IS NOT NULL ');   
        $this->db->from('users');       

        $i = 0;

        if (@$_POST['search']['value']) {
            foreach ($this->customer_column_search as $item) {
                if ($i === 0) {
                    $this->db->group_start()
                        ->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->customer_column_search) - 1 == $i) {
                    $this->db->group_end();
                }
                $i++;
            }
        }       

    }

    public function getSourceData()
    {
    // public function getSourceData($dateFrom, $dateThru)
    // {
        // $this->db->where('DATE(date_selling) >=', $dateFrom);
        // $this->db->where('DATE(date_selling) <=', $dateThru);
        $this->db->select('status_checker, COUNT(*) as count');
        $this->db->from('checker');
        $this->db->group_by('status_checker');
        $query = $this->db->get();
        return $query->result_array();
    }

    // public function getSourceDataMultiple($year)
    // {
    //     $this->db->select('status_checker, MONTH(create_date) as month, COUNT(*) as count');
    //     $this->db->from('checker');
    //     $this->db->where('YEAR(create_date)', $year); // Filter berdasarkan tahun
    //     $this->db->group_by(['MONTH(create_date)', 'status_checker']);
    //     $this->db->order_by('month', 'ASC');
    //     $query = $this->db->get();

    //     return $query->result_array(); // Kembalikan hasil dalam bentuk array
    // }

    public function getSourceDataMultiple($year)
{
    $this->db->select('status_checker, MONTH(create_date) AS month, COUNT(*) AS count');
    $this->db->from('checker');
    $this->db->where('YEAR(create_date)', $year);
    $this->db->group_by(['status_checker', 'MONTH(create_date)']);
    $this->db->order_by('status_checker', 'ASC');
    $this->db->order_by('month', 'ASC');
    if (!empty($dateFrom) && !empty($dateThru)) {
        $this->db->where('DATE(create_date) >=', $dateFrom);
        $this->db->where('DATE(create_date) <=', $dateThru);
    }
    
    return $this->db->get()->result_array();
}
    public function _get_zones()
    {
        $this->db->distinct();
        $this->db->select('*');
        $this->db->from('zone_codes');
        $query = $this->db->get();
        $result = $query->result();        
        return $result; 
    }
    public function _destination_code($zone_code)
    {
        $this->db->distinct();
        $this->db->select('*');
        $this->db->from('destination_code');
        $this->db->where('origin_code',$zone_code);
        $query = $this->db->get();
        $result = $query->result();        
        return $result; 
    }
    function getdatatables_customer()
    {
        //
        $this->_getdatatables_customer();
        if (@$_POST['length'] != -1)
            $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }


    private function _getdatatables_user()
    {
        $this->db->select('*');
        $this->db->from('users');                               
                                

        $i = 0;

        if (@$_POST['search']['value']) {
            foreach ($this->customer_column_search as $item) {
                if ($i === 0) {
                    $this->db->group_start()
                        ->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->customer_column_search) - 1 == $i) {
                    $this->db->group_end();
                }
                $i++;
            }
        }

        if (isset($_POST['order'])) {
            $column_order_index = $_POST['order']['0']['column'];
            if ($this->customer_column_order[$column_order_index] != null) {
                $this->db->order_by($this->customer_column_order[$column_order_index], $_POST['order']['0']['dir']);
            }
        } elseif (isset($this->order)) {
            $customer_order = $this->order;
            $this->db->order_by(key($customer_order), $customer_order[key($customer_order)]);
        }

    }

    function getdatatables_user()
    {
        $this->_getdatatables_user();
        if (@$_POST['length'] != -1)
            $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_customer()
    {
        $this->_getdatatables_customer();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_customer()
    {
        $this->db->select('*');

        $this->db->from('users');
        return $this->db->count_all_results();
    }
    function count_filtered_user()
    {
        //
        $this->_getdatatables_user();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_user()
    {
        //
        $this->db->select('*');
        $this->db->from('users');
        return $this->db->count_all_results();
    }




}

?>